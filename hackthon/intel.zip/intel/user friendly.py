import streamlit as st
import numpy as np
import joblib

# Load the trained model
model = joblib.load("/home/hgidea/Desktop/Coding/Python/hackthon/intel/best_random_forest_model.pkl")

# Define a function to make predictions
def predict_aqi(features):
    features_array = np.array(features).reshape(1, -1)
    prediction = model.predict(features_array)
    return prediction[0]

# Streamlit App
st.title('Air Quality Index (AQI) Prediction')

# Define input widgets for user input
country = st.selectbox('Country', ['Country A', 'Country B', 'Country C'])
city = st.text_input('City', 'City X')
pm25_aqi = st.slider('PM2.5 AQI Value', min_value=0, max_value=500, value=100)
ozone_aqi = st.slider('Ozone AQI Value', min_value=0, max_value=500, value=50)
co_aqi = st.slider('CO AQI Value', min_value=0, max_value=500, value=20)
no2_aqi = st.slider('NO2 AQI Value', min_value=0, max_value=500, value=30)

# Make prediction based on user input
features = [pm25_aqi, ozone_aqi, co_aqi, no2_aqi]
prediction = predict_aqi(features)

# Display prediction
st.write('### Predicted AQI Value:')
st.write(prediction)
