# app.py (Flask)
from flask import Flask, render_template
from streamlit.components.v1 import html as st_html

app = Flask(__name__)

@app.route('/')
def index():
    # Render the Streamlit app HTML
    streamlit_html = st_html('<iframe src="/streamlit" width="100%" height="100%" style="border: none;"></iframe>', height=800)
    return render_template('index.html', streamlit_html=streamlit_html)

if __name__ == '__main__':
    app.run(debug=True)
